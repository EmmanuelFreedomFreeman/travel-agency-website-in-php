<h3 class="hny-title mb-5">Modify a Booking</h3>
   
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">destination</th>
      <th scope="col">duree visa</th>
      <th scope="col">amount</th>
      <th scope="col">description</th>
      <th scope="col">click to modify</th>
    </tr>
  </thead>
  <tbody>
   
<?php
          include_once 'connexionDAO.php';
          $get_class = new Connexion();

          $select_All_books = $get_class->Select_All_Jobs();
        $a = 1;
          foreach($select_All_books as $key=>$value){
            ?>

                <tr>
                <th scope="row"><?php echo $a++; ?></th>
                <td><?php echo $value['destination']; ?></td>
                <td><?php echo $value['temp']; ?></td>
                <td>$<?php echo $value['amount']; ?></td>
                <td><?php echo $value['description']; ?></td>
                <td>
                    <a href="modify_book.php?id=<?php echo $value['id']; ?>">
                    <img src="<?php echo $value['photo']; ?>" style="max-width: 70px;max-height: 70px;"/>
                    </a>
                    
                </td>
                </tr>


            <?php

          }

          ?>
    
  </tbody>
</table>

