<?php 

include_once 'header.php';

?>
        <!-- //header -->
        <!-- about breadcrumb -->
        <section class="w3l-about-breadcrumb text-left">
            <div class="breadcrumb-bg breadcrumb-bg-about py-sm-5 py-4">
                <div class="container py-2">
                    <h2 class="title">About Us</h2>
                    <ul class="breadcrumbs-custom-path mt-2">
                        <li><a href="#url">Home</a></li>
                        <li class="active"><span class="fa fa-arrow-right mx-2" aria-hidden="true"></span> About </li>
                    </ul>
                </div>
            </div>
        </section>
        <!-- //about breadcrumb -->
        <!-- /about-6-->
        <section class="w3l-cta4 py-5">
            <div class="container py-lg-5">
                <div style="margin: 8px auto; display: block; text-align:center;">

                    <!---728x90--->


                </div>
                <div class="ab-section text-center">
                    <h6 class="sub-title">About Us</h6>
                    <h3 class="hny-title">Travel to make memories all around the world.</h3>
                    <p class="py-3 mb-3">Towes is a well established travel agency & tour operator offering services worldwide. It is operational since 1997 in the Democratic Republic of Congo. We are committed to offering travel services of the highest quality, combining
                        our energy and enthusiasm, with our years of experience. Our greatest satisfaction comes in serving large numbers of satisfied clients who have experienced the joys and inspiration of travel. We also organize customize tours in
                        several regions of the Democratic republic of Congo. Our principle activities consist of booking & issuing of tickets on both local and international network. We also facilitate with travel document delivery and related services.</p>
                    <a href="#" class="btn btn-style btn-primary">Read More</a>
                </div>
                <div class="row mt-5">
                    <div class="col-md-9 mx-auto">
                        <img src="assets/images/banner3.jpg" class="img-fluid" alt="">
                    </div>
                </div>
            </div>
        </section>
        <!-- //about-6-->

        <!-- //team -->

        <!--/w3l-footer-29-main-->
        <?php 

include_once 'footer.php';

?>