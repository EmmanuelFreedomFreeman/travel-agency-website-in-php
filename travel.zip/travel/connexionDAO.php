<?php

	class Connexion {
		function getConnexion() {
			try {
				$host = 'mysql:host=localhost;dbname=travel';
				$user = 'root';
				$pwd = '';
				$bdd = new PDO($host, $user, $pwd,
				array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
			
			} catch(Exception $e) {
				die('Erreur : '.$e->getMessage());
			}
			
			return $bdd;
		}
        						
        function Insert_Users($nom,$username,$password){
            $req=$this->getConnexion()->prepare('insert into users(nom,username,password)VALUES(:nom,:username,:password)');
            $r=$req->execute(array(
                'nom'=>$nom,'username'=>$username,'password'=>$password
            ));
            if ($r==true){
                return true;
            }else{
                return false;
            }
        }
        function Select_Users($username,$password){
            $req=$this->getConnexion()->prepare('select * from users where username=:username and password=:password');
            $req->execute(array(
                'username'=>$username,'password'=>$password
            ));
            return $req->fetchAll();
        }
        
        function Update_User($id,$nom,$username,$password){
            $req=$this->getConnexion()->prepare('update users set nom=:nom,username=:username,password=:password WHERE id=:id');
            $r=$req->execute(array(
                'id'=>$id,'nom'=>$nom,'username'=>$username,'password'=>$password
            ));
            if ($r==true){
                return true;
            }else{
                return false;
            }
        }
    function Insert_Job($destination,$temp,$amount,$description,$photo){
        $req=$this->getConnexion()->prepare('insert into book(destination,temp,amount,description,photo)VALUES(:destination,:temp,:amount,:description,:photo)');
        $r=$req->execute(array(
            'destination'=>$destination,'temp'=>$temp,'amount'=>$amount,'description'=>$description,'photo'=>$photo
        ));
        if ($r==true){
            return true;
        }else{
            return false;
        }
    }
    function update_Job($id,$destination,$temp,$amount,$description,$photo,$etat){
        $req=$this->getConnexion()->prepare('update book set destination=:destination,temp=:temp,amount=:amount,description=:description,photo=:photo,etat=:etat WHERE id=:id');
        $r=$req->execute(array(
            'id'=>$id,'destination'=>$destination,'temp'=>$temp,'amount'=>$amount,'description'=>$description,'photo'=>$photo,'etat'=>$etat
        ));
        if ($r==true){
            return true;
        }else{
            return false;
        }
    }
    function update_Book_ById($id,$etat){
        $req=$this->getConnexion()->prepare('update book set etat=:etat WHERE id=:id');
        $r=$req->execute(array(
            'id'=>$id,'etat'=>$etat
        ));
        if ($r==true){
            return true;
        }else{
            return false;
        }
    }
    function Select_All_Jobs(){
        $req=$this->getConnexion()->prepare('select * from book order by id desc ');
        $req->execute(array(
			
        ));
        return $req->fetchAll();
    }
    
    function Select_All_JobsById($id){
        $req=$this->getConnexion()->prepare('select * from book where id=:id ');
        $req->execute(array(
			'id'=>$id
        ));
        return $req->fetchAll();
	}

	
	





}

?>

