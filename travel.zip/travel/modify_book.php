<?php include_once'header.php'; ?>
<!--  Work gallery section -->
<section class="w3l-about-breadcrumb text-left">
    <div class="breadcrumb-bg breadcrumb-bg-about py-sm-5 py-4">
      <div class="container py-2">
        <h2 class="title">MODIFY A BOOKING</h2>

        <a href='admin.php' class="btn btn-success" >admin</a>
        
      </div>
    </div>
  </section>
<section class="grids-1 py-5">
  <div class="grids py-lg-5 py-md-4">
      <div class="container">
        <div style="margin: 8px auto; display: block; text-align:center;">

          <!---728x90--->
          <?php
          include_once 'connexionDAO.php';
          $get_class = new Connexion();

          $select_All_books = $get_class->Select_All_JobsById($_GET['id']);

         
            ?>
           
          </div>
          <div id="yy">

<form enctype="multipart/form-data" method="POST">
                        <div class="register-form">
                        
                            <div class="row">
                                <div class="col-md-6">
                                    <label>destination</label>
                                    <input name="destination" class="form-control" type="text" value="<?php echo $select_All_books[0]['destination'];?>"  required>
                                </div>
                                <div class="col-md-6">
                                    <label>duree du visa</label>
                                    <input name="temp" class="form-control" type="text" value="<?php echo $select_All_books[0]['temp'];?>"  required>
                                </div>
                                <div class="col-md-6">
                                    <label>amount</label>
                                    <input name="amount" class="form-control" type="text" value="<?php echo $select_All_books[0]['amount'];?>" required>
                                </div>
                               
                                <div  class="col-md-6" >
                                    <label for="w3review">Description</label>
                                    <textarea id="w3review"  rows="4" cols="50" name="description">
                                    <?php echo $select_All_books[0]['description'];?>

                                    </textarea>
                                </div>
                                <div class="col-md-6">
                                    <label for="exampleFormControlFile1">photo</label>
                                    <input type="file" class="form-control-file" name="photo">
                                </div>
                                <div class="col-md-12">
                                    <button class="btn btn-success">Submit</button>
                                </div>
                            </div>
                        </div>
                        </form>

                        <?php


if(isset($_POST) and isset($_FILES['photo']) ){

    include('class.uploader.php');
    include_once 'connexionDAO.php';

    $uploader = new Uploader();
    $data = $uploader->upload($_FILES['photo'], array(
        'limit' => 10, //Maximum Limit of files. {null, Number}
        'maxSize' => 10, //Maximum Size of files {null, Number(in MB's)}
        'extensions' => null, //Whitelist for file extension. {null, Array(ex: array('jpg', 'png'))}
        'required' => false, //Minimum one file is required for upload {Boolean}
        'uploadDir' => 'uploads/', //Upload directory {String}
        'title' => array('auto', 10), //New file name {null, String, Array} *please read documentation in README.md
        'removeFiles' => true, //Enable file exclusion {Boolean(extra for jQuery.filer), String($_POST field name containing json data with file names)}
        'replace' => false, //Replace the file if it already exists  {Boolean}
        'perms' => null, //Uploaded file permisions {null, Number}
        'onCheck' => null, //A callback function name to be called by checking a file for errors (must return an array) | ($file) | Callback
        'onError' => null, //A callback function name to be called if an error occured (must return an array) | ($errors, $file) | Callback
        'onSuccess' => null, //A callback function name to be called if all files were successfully uploaded | ($files, $metas) | Callback
        'onUpload' => null, //A callback function name to be called if all files were successfully uploaded (must return an array) | ($file) | Callback
        'onComplete' => null, //A callback function name to be called when upload is complete | ($file) | Callback
        'onRemove' => 'onFilesRemoveCallback' //A callback function name to be called by removing files (must return an array) | ($removed_files) | Callback
    ));

    if($data['isComplete']){
        $files = $data['data'];
        

        $get_class = new Connexion();
        $destination = $_POST['destination'];
        $temp = $_POST['temp'];
        $amount = $_POST['amount'];
        $description = $_POST['description'];
        
        
        if(count($files['files'])<1){
            $photo = $select_All_books[0]['photo'];
            
        }else{
            $photo = $files['files'][0];
            
        }
       

        $insert_book = $get_class->update_Job($_GET['id'],$destination,$temp,$amount,$description,$photo,'');

        ?>
            <div class="alert alert-success" role="alert">
            This is a success modification !
            </div>

<?php

    }

    if($data['hasErrors']){
        $errors = $data['errors'];
        ?>
        <div class="alert alert-success" role="alert">
            <?php print_r($errors); ?>
            </div>
        <?php
    }

}



?>


</div>
          
          </div>
    </div></section>
    <!--  //Work gallery section -->
    <!-- grids block 5 -->
    <div style="margin: 8px auto; display: block; text-align:center;">
    
      <!---728x90--->
       
      </div>
      <!--/w3l-footer-29-main-->
     

<?php include_once'footer.php'; ?>