
<!--
Author: W3layouts
Author URL: http://w3layouts.com
-->
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>AFRIBOX</title>

  <!-- Template CSS -->
  <link rel="stylesheet" href="assets/css/style-starter.css">

  <!-- google fonts -->
  <link href="//fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900&display=swap" rel="stylesheet">
</head>

<body class="sidebar-menu-collapsed" style='background-image: url("bac.jpg");'>

  <section>

    <!-- content -->
    <div class="">
        <!-- login form -->
        <section class="login-form py-md-5 py-3">
            <div class="card card_border p-md-4">
                <div class="card-body">
                    <!-- form -->
                    <form action="#" method="post">
                        <div class="login__header text-center mb-lg-5 mb-4">
                            
                            <h3 class="login__title mb-2"> Login</h3>
                            <p>Bienvenue à nouveau, connectez-vous pour continuer</p>

                            <div id='h'>
                                <?php
                                                                
                                if(!isset($_SESSION)){
                                    session_start();
                                    
                                }
                                
                                if((isset($_SESSION['user']) and count($_SESSION['user'])<=0)){
                                    
                                    ?>
                                <div class="alert alert-danger" role="alert">
                                <div onclick="$('#h').hide();" class="btn btn-primary btn-style mt-4" style='float:right;'>X</div>
                                l'utilisateur est incorrecte
                                </div>
                                    <?php
                                }
                                ?>
                            
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1" class="input__label">Nom d'utilisateur</label>
                            <input type="text" name='username' class="form-control login_text_field_bg input-style"
                                id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="" required=""
                                autofocus>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1" class="input__label">Mot de passe</label>
                            <input type="password" name='password' class="form-control login_text_field_bg input-style"
                                id="exampleInputPassword1" placeholder="" required>
                        </div>
                        
                        <div class="d-flex align-items-center flex-wrap justify-content-between">
                            <button type="submit" class="btn btn-primary btn-style mt-4">Connecte-toi maintenant</button>
                            
                        </div>
                    </form>
                    <!-- //form -->
                    <p class="backtohome mt-4"><a href="./" class="back"><i class="fa fa-chevron-left"
                                aria-hidden="true"></i>Back to Home </a></p>
                </div>
            </div>
        </section>

    </div>
    <!-- //content -->

</section>


</body>

</html>
<link href="dist/styles/metro/notify-metro.css" rel="stylesheet" />
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<script src="dist/notify.js"></script>
	<script src="dist/styles/metro/notify-metro.js"></script>
<?php

    include_once 'connexionDAO.php';
    $get_class = new Connexion();

    if(isset($_POST['username'])){
        $user = $get_class->Select_Users($_POST['username'],$_POST['password']);
        

        if(count($user)<= 0){
            $_SESSION['user'] = array();
                ?>
                
                <script>
                    $('#h').show();
                </script>
                <?php
        }else{
            $_SESSION['user'] = $user;
            ?>

            <script>
                document.location.href = 'admin.php';
            </script>
            
            
            <?php
        }
    }

    




?>
 <script type="text/javascript">
     
    
 </script>