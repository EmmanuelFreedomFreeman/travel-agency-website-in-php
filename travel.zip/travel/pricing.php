<?php include_once'header.php'; ?>
  <!-- //header -->
  <!-- about breadcrumb -->
  <section class="w3l-about-breadcrumb text-left">
    <div class="breadcrumb-bg breadcrumb-bg-about py-sm-5 py-4">
      <div class="container">
        <h2 class="title">Packages</h2>
        <ul class="breadcrumbs-custom-path mt-2">
          <li><a href="#url">Home</a></li>
          <li class="active"><span class="fa fa-arrow-right mx-2" aria-hidden="true"></span> Packages </li>
        </ul>
      </div>
    </div>
  </section>
  <!-- //about breadcrumb -->
  <!--/pricing-->
  <section class="w3l-pricinghny">
    <div class="pricing-inner-info py-5">
      <div style="margin: 8px auto; display: block; text-align:center;">

        <!---728x90--->

         
        </div>
      <div class="container py-lg-4">
        <!--/pricing-info-grids-->
        <div class="pricing-info-grids">
          <!--/box-->
          <?php
          include_once 'connexionDAO.php';
          $get_class = new Connexion();

          $select_All_books = $get_class->Select_All_Jobs();

          foreach($select_All_books as $key=>$value){
            if($value['etat'] != 'block'){
              ?>
              <div class="price-box">
                <div class="grid grid-column-2">
                  <div class="column pr-img-gd">
                    <h6 class="pricehead"><span class="fa fa-delicious mr-2" aria-hidden="true"></span> <?php echo $value['destination']; ?>
                    </h6>
                  </div>
                  <div class="column text-lg-center">
                    <p class="price-title"><?php echo $value['temp']; ?></p>
                  </div>
                  <div class="column price-number text-md-right">
                    <h3 class="pricing"> <sup class="pri1">$</sup><?php echo $value['amount']; ?><sup class="pri">99</sup>
                    </h3>
                    <a style='margin-top: 5px;' href="https://wa.me/+243992237080?text=Destination:  <?php echo $value['destination']; ?> et la duree du visa: <?php echo $value['temp']; ?> et le montant: $<?php echo $value['amount']; ?>" class="btn btn-style btn-success" target="_blank" >
                      Book now
                    </a>
                  </div>
                </div>
              </div>
              <!--/box-->
              
              <?php
            }
            
          }


      ?>
        
        </div>
        <!--/pricing-info-grids-->
      </div>
    </div>
  </section>
  <!--//pricing-->
  <div style="margin: 8px auto; display: block; text-align:center;">

    <!---728x90--->
     
    </div>
  <!--/w3l-footer-29-main-->
  <?php include_once'footer.php'; ?>