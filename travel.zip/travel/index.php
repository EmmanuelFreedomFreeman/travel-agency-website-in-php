<?php include_once'header.php'; ?>
  <!--banner-slider-->
  <!-- main-slider -->
  <section class="w3l-main-slider" id="home">
    <div class="banner-content">
      <div id="demo-1"
        data-zs-src='["assets/images/banner1.jpg", "assets/images/banner2.jpg","assets/images/banner3.jpg", "assets/images/banner4.jpg"]'
        data-zs-overlay="dots">
        <div class="demo-inner-content">
          <div class="container">
            <div class="banner-infhny">
              <h3> Discover your next adventure </h3>
              <h6 class="mb-3">Towes Sarl is a one stop shop for all your travel needs. We have a sense of consideration for our customers & the satisfaction of our customer is paramount. We are in your care before and after your trip.</h6>
              
              <div class="flex-wrap search-wthree-field mt-md-5 mt-4">
                <form  method="post" class="booking-form">
                  <div class="row book-form">
                    <div class="form-input col-md-4 mt-md-0 mt-3">

                      <select  class="selectpicker" name='destinaion'>
                        <option value="">Destinaion</option>
                        <option value="africa">Africa</option>
                        <option value="america">America</option>
                        <option value="asia">Asia</option>
                        <option value="eastern-europe">Eastern Europe</option>
                        <option value="europe">Europe</option>
                        <option value="south-america">South America</option>
                      </select>

                    </div>
                    <div class="form-input col-md-4 mt-md-0 mt-3">

                      <input type="date" name="date" placeholder="Date" required="">
                    </div>
                    <div class="bottom-btn col-md-4 mt-md-0 mt-3">
                      <button class="btn btn-style btn-success"><span class="fa fa-whatsapp mr-3"
                          aria-hidden="true"></span> Book Now</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <?php
  
  if (isset($_POST['date']) and isset($_POST['destinaion'])){
    
    ?>
  <script>
    window.open("https://wa.me/+243992237080?text=Destination:  <?php echo $_POST['destinaion']; ?> et la date de depart: <?php echo $_POST['date']; ?>");
  </script>

    <?php
      $_POST = array();
  }


  ?>
  <!-- /main-slider -->
  <!-- //banner-slider-->

  <!--/grids-->
  <section class="w3l-grids-3 py-5">
    <div class="container py-md-5">
      <div style="margin: 8px auto; display: block; text-align:center;">

        <!---728x90--->

         
        </div>
      <div class="title-content text-left mb-lg-5 mb-4">
        <h6 class="sub-title">Visit</h6>
        <h3 class="hny-title">Popular Destinations</h3>
      </div>
      <div style="margin: 8px auto; display: block; text-align:center;">

        <!---728x90--->
         
        </div>
      <div class="row bottom-ab-grids">
  <!--/row-grids-->

      <?php
          include_once 'connexionDAO.php';
          $get_class = new Connexion();

          $select_All_books = $get_class->Select_All_Jobs();

          foreach($select_All_books as $key=>$value){
              
            if($value['etat'] != 'block'){
              ?>

              <div class="col-lg-6 subject-card mt-lg-0 mt-4">
                <div class="subject-card-header p-4">
                  <a href="https://wa.me/+243992237080?text=Destination:  <?php echo $value['destination']; ?> et la duree du visa: <?php echo $value['temp']; ?> et le montant: $<?php echo $value['amount']; ?>" class="card_title p-lg-4d-block" target="_blank" >
                    <div class="row align-items-center">
                      <div class="col-sm-5 subject-img">
                        <img src="<?php echo $value['photo']; ?>" class="img-fluid" alt="">
                      </div>
                      <div class="col-sm-7 subject-content mt-sm-0 mt-4">
                        <h4><?php echo $value['destination']; ?></h4>
                        <p><?php echo $value['temp']; ?></p>
                        <div class="dst-btm">
                          <h6 class=""> Start From </h6>
                          <span>$<?php echo $value['amount']; ?></span>
                        </div>
                        <p class="sub-para"><?php echo $value['description']; ?></p>
                        
                      </div>
                      
                    </div>
                  </a>
                  <a style='margin-top: 5px;' href="https://wa.me/+243992237080?text=Destination:  <?php echo $value['destination']; ?> et la duree du visa: <?php echo $value['temp']; ?> et le montant: $<?php echo $value['amount']; ?>" class="btn btn-style btn-success" target="_blank" >
                    Book now
                  </a>
                </div>
                
              </div>
      
      
                  <?php
            }
           
          }


      ?>
        
        
          
          <!--//row-grids-->
      </div>
    </div>
  </section>
  <!--//grids-->
  <!-- stats -->
  <section class="w3l-stats py-5" id="stats">
    <div class="gallery-inner container py-lg-0 py-3">
      <div class="row stats-con pb-lg-3">
        <div class="col-lg-3 col-6 stats_info counter_grid">
          <p class="counter">730</p>
          <h4>Branches</h4>
        </div>
        <div class="col-lg-3 col-6 stats_info counter_grid1">
          <p class="counter">1680</p>
          <h4>Travel Guides</h4>
        </div>
        <div class="col-lg-3 col-6 stats_info counter_grid mt-lg-0 mt-5">
          <p class="counter">812</p>
          <h4>Happy Customers</h4>
        </div>
        <div class="col-lg-3 col-6 stats_info counter_grid2 mt-lg-0 mt-5">
          <p class="counter">990</p>
          <h4>Awards</h4>
        </div>
      </div>
    </div>
  </section>
  <!-- //stats -->
  <!--/-->

  <?php
if(count($select_All_books)<1){

}else{
  ?>
<div class="best-rooms py-5">
    <div class="container py-md-5">
        <div class="ban-content-inf row">
            <div class="maghny-gd-1 col-lg-6">
              <div class="maghny-grid">
                <figure class="effect-lily border-radius  m-0">
                    <img class="img-fluid" src="assets/images/g10.jpg" alt="" />
                    <figcaption>
                        <div>
                            <h4><?php echo $select_All_books[0]['temp'] ?></h4>
                            <p>$<?php echo $select_All_books[0]['amount'] ?> </p>
                        </div>

                    </figcaption>
                </figure>
            </div>
            </div>
            <div class="maghny-gd-1 col-lg-6 mt-lg-0 mt-4">
                <div class="row">
                    <div class="maghny-gd-1 col-6">
                        <div class="maghny-grid">
                            <figure class="effect-lily border-radius">
                                <img class="img-fluid" src="assets/images/g9.jpg" alt="" />
                                <figcaption>
                                    <div>
                                    <h4><?php echo $select_All_books[1]['temp'] ?></h4>
                                    <p>$<?php echo $select_All_books[1]['amount'] ?> </p>
                                    </div>

                                </figcaption>
                            </figure>
                        </div>
                    </div>
                    <div class="maghny-gd-1 col-6">
                        <div class="maghny-grid">
                            <figure class="effect-lily border-radius">
                                <img class="img-fluid" src="assets/images/g8.jpg" alt="" />
                                <figcaption>
                                    <div>
                                    <h4><?php echo $select_All_books[2]['temp'] ?></h4>
                                    <p>$<?php echo $select_All_books[2]['amount'] ?> </p>
                                    </div>

                                </figcaption>
                            </figure>
                        </div>
                    </div>
                    <div class="maghny-gd-1 col-6 mt-4">
                        <div class="maghny-grid">
                            <figure class="effect-lily border-radius">
                                <img class="img-fluid" src="assets/images/g7.jpg" alt="" />
                                <figcaption>
                                    <div>
                                    <h4><?php echo $select_All_books[3]['temp'] ?></h4>
                                    <p>$<?php echo $select_All_books[3]['amount'] ?> </p>
                                    </div>

                                </figcaption>
                            </figure>
                        </div>
                    </div>
                    <div class="maghny-gd-1 col-6 mt-4">
                        <div class="maghny-grid">
                            <figure class="effect-lily border-radius">
                                <img class="img-fluid" src="assets/images/g6.jpg" alt="" />
                                <figcaption>
                                    <div>
                                    <h4><?php echo $select_All_books[4]['temp'] ?></h4>
                                    <p>$<?php echo $select_All_books[4]['amount'] ?> </p>
                                    </div>

                                </figcaption>
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
  <?php
}

?>
  
  <!-- //stats -->
  <!--/w3l-bottom-->
  <section class="w3l-bottom py-5">
    <div class="container py-md-4 py-3 text-center">
      <div class="row my-lg-4 mt-4">
        <div class="col-lg-9 col-md-10 ml-auto">
          <div class="bottom-info ml-auto">
            <div class="header-section text-left">
              <h3 class="hny-title two">Traveling makes a man wiser, and more happy.</h3>
              <p class="mt-3 pr-lg-5">1937 , Blv , M'siri , Q/ Industriel, Commune Kapemba, Ref, Arret CABINE Contact : +243992237080, +243908985846 , email : reziakaseba@yahoo.fr , Lubumbashi/ Haut - katanga.</p>
              
            </div>
           

          </div>
        </div>
      </div>
    </div>
  </section>
  <!--//w3l-bottom-->
  <!-- testimonials -->
  
  <!-- //testimonials -->
  <div style="margin: 8px auto; display: block; text-align:center;">

    <!---728x90--->
     
    </div>
  <!--/w3l-footer-29-main-->

  <?php
  
  include_once 'footer.php';
  ?>