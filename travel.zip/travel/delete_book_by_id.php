<?php
          include_once 'connexionDAO.php';
          $get_class = new Connexion();

          $select_All_books = $get_class->Select_All_JobsById($_GET['id']);


          if($select_All_books[0]['etat'] == ''){
            $update_All_books = $get_class->update_Book_ById($_GET['id'],'block');
            ?>
            <script>
                window.location = "admin.php?cle=3";
            </script>
            <?php
          }else{
            $update_All_books = $get_class->update_Book_ById($_GET['id'],'');
            ?>
            <script>
                window.location = "admin.php?cle=3";
            </script>
            <?php
          }


          
       
          





            ?>